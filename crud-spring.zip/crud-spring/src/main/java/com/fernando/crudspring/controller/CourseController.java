package com.fernando.crudspring.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fernando.crudspring.model.Course;
import com.fernando.crudspring.repository.CourseRepository;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Validated
@RestController
@RequestMapping("/api/courses")
@AllArgsConstructor // Posso criar um constructor também e não é muito indicado como boas práticas a utilização do @Awired e Setter para fazer a instância.
public class CourseController {
    
    private final CourseRepository courseRepository;

    // @RequestMapping(method=RequestMethod.GET) Mesma coisa que o @GetMapping
    @GetMapping
    public List<Course> list() {
        return courseRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> findById(@PathVariable @NotNull @Positive Long id) { // Eu posso passar o nome para o @PathVariable("id") e meu parâmetro Long id eu posso dar o nome que eu quiser. Porque o nome do @PathVariable já faz o match com o @GetMapping.
        return courseRepository.findById(id)
                .map(recordFound -> ResponseEntity.ok().body(recordFound))
                .orElse(ResponseEntity.notFound().build());
    }

    // @RequestMapping(method=RequestMethod.POST)
    @PostMapping
    // @ResponseStatus(code = HttpStatus.CREATED) Podemos usar essa forma simplificada já que não iremos manipular a request, lidar com o header, outras coisas. Só queremos o código de status. E para isso não precisa mais retornar um ResponseEntity, apenas dar o retorno normal e marcar o método create com o tipo Course.
    // @Valid vai validar o JSON que foi transformado para a instância da nossa variável course, se contém às informações válidas de acordo com que nós implementamos na Model.
    public ResponseEntity<Course> create(@RequestBody @Valid Course course) {
        // return courseRepository.save(course);
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(courseRepository.save(course));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> update(@PathVariable @NotNull @Positive Long id, @RequestBody @Valid Course course) {
        // Não vamos atualizar o id, porque é até perigoso fazer isso. E quando atualizarmos nossos dados que veio da requisição, do corpo, o próprio Hibernate, o JPA, vão identificar e ter a noção que precisa atualizar o insert na base de dados.
        return courseRepository.findById(id)
            .map(recordFound -> {
                recordFound.setName(course.getName());
                recordFound.setCategory(course.getCategory());
                Course updated = courseRepository.save(recordFound);
                return ResponseEntity.ok().body(updated);})
            .orElse(ResponseEntity.notFound().build());
    }

    // O que a gente fez no Postman foi deletar fisicamente (hard delete, fisical delete), porém em algumas linguagens mesmo a gente deletando algo, ainda vai existir o registro na base.
    // O que podemos fazer é ter uma coluna Status e quando deletar, a gente faz um update dessa Coluna Status para Status Inativo. E se não for deletada ela será Status Ativo.
    // Dependendo da nossa aplicação, podemos pegar o status do objetivo (setter) e definir isso na configuração.
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable @NotNull @Positive Long id) {
        return courseRepository.findById(id)
            .map(recordFound -> {
                courseRepository.deleteById(id);
                return ResponseEntity.noContent().<Void>build();})
            .orElse(ResponseEntity.notFound().build());
    }
}
